package web.controller.mypage.activity;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class MypageActivityBookMarkController
 */
@WebServlet("/activity/bookmarklist")
public class MypageActivityBookMarkController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
