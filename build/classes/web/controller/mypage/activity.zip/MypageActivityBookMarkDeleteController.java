package web.controller.mypage.activity;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class MypageActivityBookMarkDeleteController
 */
@WebServlet("/activity/bookmarkdelete")
public class MypageActivityBookMarkDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
