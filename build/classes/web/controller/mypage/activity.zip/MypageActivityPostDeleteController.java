package web.controller.mypage.activity;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class MypageActivityPostDeleteController
 */
@WebServlet("/activity/postdelete")
public class MypageActivityPostDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

}
